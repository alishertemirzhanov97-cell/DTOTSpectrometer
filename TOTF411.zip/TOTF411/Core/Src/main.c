/* USER CODE BEGIN Header */



/**



  ******************************************************************************



  * @file           : main.c



  * @brief          : Main program body



  ******************************************************************************



  * @attention



  *



  * Copyright (c) 2026 STMicroelectronics.



  * All rights reserved.



  *



  * This software is licensed under terms that can be found in the LICENSE file



  * in the root directory of this software component.



  * If no LICENSE file comes with this software, it is provided AS-IS.



  *



  ******************************************************************************



  */



/* USER CODE END Header */



/* Includes ------------------------------------------------------------------*/



#include "main.h"



#include "usb_device.h"







/* Private includes ----------------------------------------------------------*/



/* USER CODE BEGIN Includes */



#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include "usbd_cdc_if.h"

#include "usbd_cdc.h"



/* USER CODE END Includes */







/* Private typedef -----------------------------------------------------------*/



/* USER CODE BEGIN PTD */



typedef struct



{



  uint32_t sync;



  uint32_t event_id;



  uint32_t tot_ticks;



} TotPacket;







_Static_assert(sizeof(TotPacket) == 12U,



               "TotPacket must be 12 bytes");



/* USER CODE END PTD */







/* Private define ------------------------------------------------------------*/



/* USER CODE BEGIN PD */



#define TIM2_CLOCK_HZ       96000000UL







#define TOT_PACKET_SYNC     0xA55A5AA5UL







#define TOT_RING_SIZE       256U



#define TOT_RING_MASK       (TOT_RING_SIZE - 1U)







/*



 * Five 12-byte events = 60 bytes,



 * fitting in one USB FS 64-byte packet.



 */



#define USB_EVENTS_PER_PACKET 5U

#define DTOT_WIDTH_DEFAULT    500U
#define DTOT_WIDTH_MIN        1U
#define DTOT_WIDTH_MAX        60000U

#define DTOT_DELAY_DEFAULT    96U

#define DTOT_DELAY_MAX        60000U

#define USB_CMD_BUFFER_SIZE   32U



/* USER CODE END PD */







/* Private macro -------------------------------------------------------------*/



/* USER CODE BEGIN PM */







/* USER CODE END PM */







/* Private variables ---------------------------------------------------------*/



TIM_HandleTypeDef htim2;



TIM_HandleTypeDef htim3;







/* USER CODE BEGIN PV */



volatile uint32_t tot_rising_ticks = 0;



volatile uint32_t tot_falling_ticks = 0;



volatile uint32_t tot_width_ticks = 0;







volatile float tot_width_us = 0.0f;



volatile float tot_width_ns = 0.0f;







volatile uint32_t tot_event_count = 0;



volatile uint32_t tot_dropped_count = 0;



volatile uint8_t tot_data_ready = 0;







/* Interrupt writes; main loop reads. */



static volatile TotPacket tot_ring[TOT_RING_SIZE];







static volatile uint16_t tot_write_index = 0;



static volatile uint16_t tot_read_index = 0;







static uint8_t usb_tx_buffer[USB_EVENTS_PER_PACKET * sizeof(TotPacket)];

static volatile uint32_t dtot_delay_ticks = DTOT_DELAY_DEFAULT;
static volatile uint32_t dtot_width_ticks = DTOT_WIDTH_DEFAULT;
static volatile uint32_t dtot_width_requested = DTOT_WIDTH_DEFAULT;

static volatile uint32_t dtot_delay_requested = DTOT_DELAY_DEFAULT;

static volatile uint8_t dtot_delay_update_pending = 0U;
static volatile uint8_t dtot_width_update_pending = 0U;

static char usb_cmd_buffer[USB_CMD_BUFFER_SIZE];

static uint8_t usb_cmd_index = 0U;



extern USBD_HandleTypeDef hUsbDeviceFS;







/*



 * USB transmission buffer must remain unchanged



 * until the transmission has completed.



 */







/* USER CODE END PV */







/* Private function prototypes -----------------------------------------------*/



void SystemClock_Config(void);



static void MX_GPIO_Init(void);



static void MX_TIM2_Init(void);



static void MX_TIM3_Init(void);



/* USER CODE BEGIN PFP */







/* USER CODE END PFP */







/* Private user code ---------------------------------------------------------*/



/* USER CODE BEGIN 0 */







/* Apply only when TIM3 has completed its current one-pulse cycle.
 * PWM2 high interval: CCR2 ... ARR, width = ARR - CCR2 + 1 ticks.
 */
static void DTOT_ApplyTiming(uint32_t delay_ticks, uint32_t width_ticks)
{
  if (delay_ticks > DTOT_DELAY_MAX ||
      width_ticks < DTOT_WIDTH_MIN || width_ticks > DTOT_WIDTH_MAX ||
      delay_ticks + width_ticks > 65535U)
    return;

  /* TIM3 must be idle: never truncate an active event. */
  if ((htim3.Instance->CR1 & TIM_CR1_CEN) != 0U)
    return;

  /* Temporarily inhibit external triggering while registers are updated. */
  uint32_t saved_smcr = htim3.Instance->SMCR;
  MODIFY_REG(htim3.Instance->SMCR, TIM_SMCR_SMS, 0U);
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, delay_ticks);
  __HAL_TIM_SET_AUTORELOAD(&htim3, delay_ticks + width_ticks - 1U);
  __HAL_TIM_SET_COUNTER(&htim3, 0U);
  if (HAL_TIM_GenerateEvent(&htim3, TIM_EVENTSOURCE_UPDATE) != HAL_OK)
    Error_Handler();
  __HAL_TIM_CLEAR_FLAG(&htim3, TIM_FLAG_UPDATE);
  htim3.Instance->SMCR = saved_smcr;
  dtot_delay_ticks = delay_ticks;
  dtot_width_ticks = width_ticks;
}

/* Called from CDC_Receive_FS() in usbd_cdc_if.c. */

void TOT_USB_CommandRx(uint8_t *data, uint32_t length)

{

  uint32_t i;



  for (i = 0U; i < length; i++)

  {

    char c = (char)data[i];



    if ((c == '\n') || (c == '\r'))

    {

      if (usb_cmd_index > 0U)

      {

        usb_cmd_buffer[usb_cmd_index] = '\0';



        if (strncmp(usb_cmd_buffer, "DLY=", 4U) == 0)

        {

          char *endptr;

          unsigned long value = strtoul(&usb_cmd_buffer[4], &endptr, 10);



          if ((*endptr == '\0') && (value <= DTOT_DELAY_MAX))

          {

            dtot_delay_requested = (uint32_t)value;

            dtot_delay_update_pending = 1U;

          }

        }



        else if (strncmp(usb_cmd_buffer, "WID=", 4U) == 0)
        {
          char *endptr;
          unsigned long value = strtoul(&usb_cmd_buffer[4], &endptr, 10);
          if ((*endptr == '\0') &&
              (value >= DTOT_WIDTH_MIN) && (value <= DTOT_WIDTH_MAX))
          {
            dtot_width_requested = (uint32_t)value;
            dtot_width_update_pending = 1U;
          }
        }

        usb_cmd_index = 0U;

      }

    }

    else if (usb_cmd_index < (USB_CMD_BUFFER_SIZE - 1U))

    {

      usb_cmd_buffer[usb_cmd_index++] = c;

    }

    else

    {

      usb_cmd_index = 0U;

    }

  }

}



static void TOT_USB_Service(void)

{

  USBD_CDC_HandleTypeDef *hcdc;

  uint16_t read_index;

  uint16_t write_snapshot;

  uint16_t count = 0U;



  hcdc = (USBD_CDC_HandleTypeDef *)hUsbDeviceFS.pClassData;



  /* Do not touch usb_tx_buffer while the previous CDC transfer is active. */

  if ((hcdc == NULL) || (hcdc->TxState != 0U))

  {

    return;

  }



  read_index = tot_read_index;

  write_snapshot = tot_write_index;



  while ((read_index != write_snapshot) &&

         (count < USB_EVENTS_PER_PACKET))

  {

    uint16_t offset = (uint16_t)(count * sizeof(TotPacket));

    TotPacket packet;



    packet.sync = tot_ring[read_index].sync;

    packet.event_id = tot_ring[read_index].event_id;

    packet.tot_ticks = tot_ring[read_index].tot_ticks;



    memcpy(&usb_tx_buffer[offset], &packet, sizeof(packet));



    read_index = (uint16_t)((read_index + 1U) & TOT_RING_MASK);

    count++;

  }



  if (count == 0U)

  {

    return;

  }



  if (CDC_Transmit_FS(usb_tx_buffer,

                      (uint16_t)(count * sizeof(TotPacket))) == USBD_OK)

  {

    tot_read_index = read_index;

  }

}



/* USER CODE END 0 */







/**



  * @brief  The application entry point.



  * @retval int



  */



int main(void)



{







  /* USER CODE BEGIN 1 */







  /* USER CODE END 1 */







  /* MCU Configuration--------------------------------------------------------*/







  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */



  HAL_Init();







  /* USER CODE BEGIN Init */







  /* USER CODE END Init */







  /* Configure the system clock */



  SystemClock_Config();







  /* USER CODE BEGIN SysInit */







  /* USER CODE END SysInit */







  /* Initialize all configured peripherals */



  MX_GPIO_Init();



  MX_TIM2_Init();



  MX_TIM3_Init();



  MX_USB_DEVICE_Init();



  /* USER CODE BEGIN 2 */



  __HAL_TIM_SET_COUNTER(&htim2, 0);







  __HAL_TIM_CLEAR_FLAG(&htim2, TIM_FLAG_CC1);



  __HAL_TIM_CLEAR_FLAG(&htim2, TIM_FLAG_CC2);



  __HAL_TIM_CLEAR_FLAG(&htim2, TIM_FLAG_CC1OF);



  __HAL_TIM_CLEAR_FLAG(&htim2, TIM_FLAG_CC2OF);







  /*



   * CH2 captures the rising edge without an interrupt.



   */



  if (HAL_TIM_IC_Start(&htim2, TIM_CHANNEL_2) != HAL_OK)



  {



    Error_Handler();



  }







  /*



   * CH1 captures the falling edge and generates an interrupt.



   */



  if (HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_1) != HAL_OK)



  {



    Error_Handler();



  }











  __HAL_TIM_DISABLE(&htim3);



  __HAL_TIM_SET_COUNTER(&htim3, 0);







  /* Load PSC and ARR values into the timer. */



  if (HAL_TIM_GenerateEvent(&htim3,



                            TIM_EVENTSOURCE_UPDATE) != HAL_OK)



  {



      Error_Handler();



  }







  __HAL_TIM_CLEAR_FLAG(&htim3, TIM_FLAG_UPDATE);



  __HAL_TIM_CLEAR_FLAG(&htim3, TIM_FLAG_CC1);



  __HAL_TIM_CLEAR_FLAG(&htim3, TIM_FLAG_CC2);



  __HAL_TIM_CLEAR_FLAG(&htim3, TIM_FLAG_CC1OF);



  __HAL_TIM_CLEAR_FLAG(&htim3, TIM_FLAG_CC2OF);







  if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2) != HAL_OK)



  {



      Error_Handler();



  }



  /* USER CODE END 2 */







  /* Infinite loop */



  /* USER CODE BEGIN WHILE */



  while (1)



  {



    /* USER CODE END WHILE */







    /* USER CODE BEGIN 3 */



	  if (tot_data_ready)



	  {



	    uint32_t local_ticks;







	    __disable_irq();







	    local_ticks = tot_width_ticks;



	    tot_data_ready = 0;







	    __enable_irq();







	    tot_width_us =



	        ((float)local_ticks * 1000000.0f) /



	        (float)TIM2_CLOCK_HZ;







	    tot_width_ns =



	        ((float)local_ticks * 1000000000.0f) /



	        (float)TIM2_CLOCK_HZ;



	  }







	  /*



	   * Transfer buffered events to the PC.



	   */



	  if ((dtot_delay_update_pending != 0U ||
       dtot_width_update_pending != 0U) &&
      ((htim3.Instance->CR1 & TIM_CR1_CEN) == 0U))
  {
    uint32_t delay, width;
    __disable_irq();
    delay = dtot_delay_update_pending ? dtot_delay_requested : dtot_delay_ticks;
    width = dtot_width_update_pending ? dtot_width_requested : dtot_width_ticks;
    if ((delay + width) <= 65535U)
    {
      dtot_delay_update_pending = 0U;
      dtot_width_update_pending = 0U;
    }
    else
    {
      /* Reject incompatible combination, preserve previous settings. */
      dtot_delay_update_pending = 0U;
      dtot_width_update_pending = 0U;
      delay = dtot_delay_ticks;
      width = dtot_width_ticks;
    }
    DTOT_ApplyTiming(delay, width);
    __enable_irq();
  }

  TOT_USB_Service();



  }



  /* USER CODE END 3 */



}







/**



  * @brief System Clock Configuration



  * @retval None



  */



void SystemClock_Config(void)



{



  RCC_OscInitTypeDef RCC_OscInitStruct = {0};



  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};







  /** Configure the main internal regulator output voltage



  */



  __HAL_RCC_PWR_CLK_ENABLE();



  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);







  /** Initializes the RCC Oscillators according to the specified parameters



  * in the RCC_OscInitTypeDef structure.



  */



  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;



  RCC_OscInitStruct.HSEState = RCC_HSE_ON;



  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;



  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;



  RCC_OscInitStruct.PLL.PLLM = 25;



  RCC_OscInitStruct.PLL.PLLN = 192;



  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;



  RCC_OscInitStruct.PLL.PLLQ = 4;



  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)



  {



    Error_Handler();



  }







  /** Initializes the CPU, AHB and APB buses clocks



  */



  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK



                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;



  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;



  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;



  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;



  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;







  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)



  {



    Error_Handler();



  }



}







/**



  * @brief TIM2 Initialization Function



  * @param None



  * @retval None



  */



static void MX_TIM2_Init(void)



{







  /* USER CODE BEGIN TIM2_Init 0 */







  /* USER CODE END TIM2_Init 0 */







  TIM_ClockConfigTypeDef sClockSourceConfig = {0};



  TIM_MasterConfigTypeDef sMasterConfig = {0};



  TIM_IC_InitTypeDef sConfigIC = {0};







  /* USER CODE BEGIN TIM2_Init 1 */







  /* USER CODE END TIM2_Init 1 */



  htim2.Instance = TIM2;



  htim2.Init.Prescaler = 0;



  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;



  htim2.Init.Period = 4294967295;



  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;



  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;



  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)



  {



    Error_Handler();



  }



  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;



  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)



  {



    Error_Handler();



  }



  if (HAL_TIM_IC_Init(&htim2) != HAL_OK)



  {



    Error_Handler();



  }



  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;



  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;



  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)



  {



    Error_Handler();



  }



  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;



  sConfigIC.ICSelection = TIM_ICSELECTION_INDIRECTTI;



  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;



  sConfigIC.ICFilter = 0;



  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)



  {



    Error_Handler();



  }



  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;



  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;



  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_2) != HAL_OK)



  {



    Error_Handler();



  }



  /* USER CODE BEGIN TIM2_Init 2 */







  /* USER CODE END TIM2_Init 2 */







}







/**



  * @brief TIM3 Initialization Function



  * @param None



  * @retval None



  */



static void MX_TIM3_Init(void)



{







  /* USER CODE BEGIN TIM3_Init 0 */







  /* USER CODE END TIM3_Init 0 */







  TIM_ClockConfigTypeDef sClockSourceConfig = {0};



  TIM_SlaveConfigTypeDef sSlaveConfig = {0};



  TIM_MasterConfigTypeDef sMasterConfig = {0};



  TIM_OC_InitTypeDef sConfigOC = {0};







  /* USER CODE BEGIN TIM3_Init 1 */







  /* USER CODE END TIM3_Init 1 */



  htim3.Instance = TIM3;



  htim3.Init.Prescaler = 0;



  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;



  htim3.Init.Period = DTOT_DELAY_DEFAULT + DTOT_WIDTH_DEFAULT - 1U;



  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;



  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;



  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)



  {



    Error_Handler();



  }



  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;



  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)



  {



    Error_Handler();



  }



  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)



  {



    Error_Handler();



  }



  if (HAL_TIM_OnePulse_Init(&htim3, TIM_OPMODE_SINGLE) != HAL_OK)



  {



    Error_Handler();



  }



  sSlaveConfig.SlaveMode = TIM_SLAVEMODE_TRIGGER;



  sSlaveConfig.InputTrigger = TIM_TS_TI1FP1;



  sSlaveConfig.TriggerPolarity = TIM_TRIGGERPOLARITY_RISING;



  sSlaveConfig.TriggerFilter = 0;



  if (HAL_TIM_SlaveConfigSynchro(&htim3, &sSlaveConfig) != HAL_OK)



  {



    Error_Handler();



  }



  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;



  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;



  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)



  {



    Error_Handler();



  }



  sConfigOC.OCMode = TIM_OCMODE_PWM2;



  sConfigOC.Pulse = DTOT_DELAY_DEFAULT;



  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;



  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;



  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)



  {



    Error_Handler();



  }



  /* USER CODE BEGIN TIM3_Init 2 */







  /* USER CODE END TIM3_Init 2 */



  HAL_TIM_MspPostInit(&htim3);







}







/**



  * @brief GPIO Initialization Function



  * @param None



  * @retval None



  */



static void MX_GPIO_Init(void)



{



  /* USER CODE BEGIN MX_GPIO_Init_1 */







  /* USER CODE END MX_GPIO_Init_1 */







  /* GPIO Ports Clock Enable */



  __HAL_RCC_GPIOC_CLK_ENABLE();



  __HAL_RCC_GPIOH_CLK_ENABLE();



  __HAL_RCC_GPIOA_CLK_ENABLE();



  __HAL_RCC_GPIOB_CLK_ENABLE();







  /* USER CODE BEGIN MX_GPIO_Init_2 */







  /* USER CODE END MX_GPIO_Init_2 */



}







/* USER CODE BEGIN 4 */



void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)



{



  if ((htim->Instance == TIM2) &&



      (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1))



  {



    uint32_t rise;



    uint32_t fall;



    uint32_t width;



    uint32_t event_id;







    uint16_t write_index;



    uint16_t next_write_index;







    rise = HAL_TIM_ReadCapturedValue(



        htim,



        TIM_CHANNEL_2);







    fall = HAL_TIM_ReadCapturedValue(



        htim,



        TIM_CHANNEL_1);







    width = fall - rise;







    tot_rising_ticks = rise;



    tot_falling_ticks = fall;



    tot_width_ticks = width;







    event_id = ++tot_event_count;







    /*



     * Add event to the USB ring buffer.



     */



    write_index = tot_write_index;







    next_write_index =



        (uint16_t)((write_index + 1U) &



                   TOT_RING_MASK);







    if (next_write_index != tot_read_index)



    {



      tot_ring[write_index].sync =



          TOT_PACKET_SYNC;







      tot_ring[write_index].event_id =



          event_id;







      tot_ring[write_index].tot_ticks =



          width;







      /*



       * Complete data writes before publishing



       * the new index.



       */



      __DMB();







      tot_write_index = next_write_index;



    }



    else



    {



      /*



       * USB/PC did not empty the buffer quickly enough.



       */



      tot_dropped_count++;



    }







    tot_data_ready = 1;







    __HAL_TIM_CLEAR_FLAG(htim, TIM_FLAG_CC2);



    __HAL_TIM_CLEAR_FLAG(htim, TIM_FLAG_CC2OF);



  }



}



/* USER CODE END 4 */







/**



  * @brief  This function is executed in case of error occurrence.



  * @retval None



  */



void Error_Handler(void)



{



  /* USER CODE BEGIN Error_Handler_Debug */



  /* User can add his own implementation to report the HAL error return state */



  __disable_irq();



  while (1)



  {



  }



  /* USER CODE END Error_Handler_Debug */



}



#ifdef USE_FULL_ASSERT



/**



  * @brief  Reports the name of the source file and the source line number



  *         where the assert_param error has occurred.



  * @param  file: pointer to the source file name



  * @param  line: assert_param error line source number



  * @retval None



  */



void assert_failed(uint8_t *file, uint32_t line)



{



  /* USER CODE BEGIN 6 */



  /* User can add his own implementation to report the file name and line number,



     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */



  /* USER CODE END 6 */



}



#endif /* USE_FULL_ASSERT */
